@extends('leave::layouts.master')

@section('content')
    <h1>Hello World</h1>

    <p>Module: {!! config('leave.name') !!}</p>
@endsection
