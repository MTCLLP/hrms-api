<?php

return [
    'name' => 'RBAC',
];
