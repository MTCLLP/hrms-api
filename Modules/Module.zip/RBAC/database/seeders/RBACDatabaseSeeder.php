<?php

namespace Modules\RBAC\Database\Seeders;

use Illuminate\Database\Seeder;

class RBACDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
