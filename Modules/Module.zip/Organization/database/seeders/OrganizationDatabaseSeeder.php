<?php

namespace Modules\Organization\Database\Seeders;

use Illuminate\Database\Seeder;

class OrganizationDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
