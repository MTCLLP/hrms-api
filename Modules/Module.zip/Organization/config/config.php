<?php

return [
    'name' => 'Organization',
];
