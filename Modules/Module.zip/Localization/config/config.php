<?php

return [
    'name' => 'Localization',
];
